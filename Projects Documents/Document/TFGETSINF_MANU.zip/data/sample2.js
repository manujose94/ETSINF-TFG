const opcua = require("node-opcua");
// Crea el objeto AAS, su variable y una pequeña simulacion de su actividad
function construct_address_space(server) {
    const addressSpace = server.engine.addressSpace;
    const namespace = addressSpace.getOwnNamespace();
    //OBJECT
    const kmt1 = namespace.addObject({
        browseName: "MKM1",
        organizedBy: addressSpace.rootFolder.objects
    });
    //VARIBALE
    const kmt1Temperature = namespace.addAnalogDataItem({
        browseName: "temperature1",
        engineeringUnitsRange: {low: -55,high: 50.0},
        engineeringUnits: opcua.standardUnits.degree_celsius,
        componentOf: kmt1
    });
    addressSpace.installHistoricalDataNode(kmt1Temperature);
    let t = 10;
    setInterval(function () { // simulacion de cambio de temperatura
        let value = (Math.sin(t / 50) * 1.90 + Math.random() * 2.80) * 6.0 + 5.0;
        kmt1Temperature.setValueFromSource({ dataType: "Double", value: value });
        t = t + 1;
    }, 200);
};
(async () => {
    const opcua = require("node-opcua");
    try {
        const server = new opcua.OPCUAServer({
            port: 26544, 
            resourcePath: "/ua/resource", //se agregará al nombre del recurso en el endpoint
            nodeset_filename: [opcua.nodesets.standard_nodeset_file ]
        });

        await server.initialize();

        construct_address_space(server);

        await server.start();
        const endpointUrl = server.endpoints[0].endpointDescriptions()[0].endpointUrl;
        console.log(" the primary server endpoint url is ", endpointUrl);
    } catch (err) {
        console.log("Error = ", error);
    }
})();