var opcua = require("node-opcua");
require("node-opcua-coreaas")(opcua);
var xmlFiles = [opcua.standard_nodeset_file,opcua.coreaas.nodeset_file];
var server = new opcua.OPCUAServer({nodeset_filename: xmlFiles,});
  
    // Se instancian los elementos de la clase opcua.coreaas

    // Crear un objeto AAS representa ISTR-MKM1-3ENG10 Communication Controller
    const myaas = addressSpace.addAssetAdministrationShell({
        browseName: "AAS Temperature",
        description: [new opcua.LocalizedText({
            locale: "en", text: "MKM1 CONTROLLER AND MINI-PROGRAMMER" }),
            new opcua.LocalizedText({ locale: "es", text: "CONTROLADOR MKM1" })],
        identification: new Identifier({
            id: "www.admin-shell.io/aas-sample/1.0",
            idType: IdentifierType.URI
        }),
        derivedFromRef: [new Key({
            idType: KeyType.IRDI,
            local: false,
            type: KeyElements.AssetAdministrationShell,
            value: "AAA#1234-454#123456789"
        })],
        assetRef: [new Key({
            idType: KeyType.URI,
            local: true,
            type: KeyElements.Asset, 
            value: "https://www.ascontecnologic.com/es/automatizacion-industrial/controladores-industriales/serie-kube/km1"
        })]
    }).addSubmodelRef([new Key({
            idType: KeyType.URI,
            local: true,
            type: KeyElements.Submodel,
            value: "./models/coreaas"
        })]);
    /**
     * Añadir un Asset
     */
    let asset = addressSpace.addAsset({
        browseName: "MKM1",
        idShort: "MKM1",
        identification: new Identifier({
            id: "https://www.ascontecnologic.com/es/automatizacion-industrial/controladores-industriales/serie-kube/km1",
            idType: IdentifierType.URI
        }),
        kind: Kind.Instance,
        description: new opcua.LocalizedText({ locale: "en", text: "MKM1 controller and programmer temperature" }),
        assetIdentificationModelRef: [new Key({
            idType: KeyType.URI,
            local: false,
            type: KeyElements.SubmodelElement,
            value: "//submodels/identification_KTY81"
        })]
    });
    myaas.hasAsset(asset);
    /*** Añadir un Submodel Tipo */
    const submodel_type = addressSpace.addSubmodel({
        browseName: "TYPEMKM1",
        kind: Kind.Type,
        idShort: "TYPEMKM1",
        identification: new Identifier({
            id: "//models/submodels/TYPEMKM1",
            idType: IdentifierType.URI
        })
    })
  /*** Añadir un Submodel Instacnia */
    const mysubmodel = addressSpace.addSubmodel({
        browseName: "MKM1AA",
        kind: Kind.Instance,
        idShort: "MKM1AA",
        identification: new Identifier({
            id: "//models/submodels/MKM1AA",
            idType: IdentifierType.URI
        })
    }).submodelOf(myaas)
        .hasSubmodelSemantic(submodel_type)
        .addParent([new Key({
            idType: KeyType.URI,
            local: true,
            type: KeyElements.AssetAdministrationShell,
            value: "www.admin-shell.io/aas-sample/1.0"
        })]);
    /*** Añadir SubmodelElementCollection*/
    let collection = addressSpace.addSubmodelElementCollection({
        idShort: "Measurement",
        submodelElementOf: mysubmodel,
        ordered: true,
        kind: Kind.Instance
    });
    /*** Añadir SubmodelProperty*/
    const temperature = addressSpace.addSubmodelProperty({
        browseName: "TEMPERATURE",
        idShort: "TEMPERATURE",
        category: PropertyCategory.VARIABLE,
        valueType: PropertyValueType.Int,
        value: {          
            dataType: "Int16",
            value: {
                get: () => {
                    return new opcua.Variant({ dataType: opcua.DataType.Int16, value: kmt1Temperature });// random value
                }
            }
        }
    }).addSemanticId([new Key({
            idType: KeyType.IRDI,
            local: true,
            type: KeyElements.ConceptDescription,
            value: "0112/2///61360_4#AAE685#001"
        })])
        .addParent(new Key({idType: KeyType.idShort,
            local: true,
            type: KeyElements.SubmodelElementCollection,
            value: "Measurement"
        }))
        .addValueId([new Key({
            idType: KeyType.URI,
            local: true,
            type: KeyElements.GlobalReference,
            value: "//value/of/temperature"
        })]);

    const tempmax = addressSpace.addSubmodelProperty({
        browseName: "TEMPMAX",
        idShort: "TEMPMAX",
        semanticId: [new Key({
            idType: KeyType.IRDI,
            local: true,
            type: KeyElements.ConceptDescription,
            value: "0112/2///61360_4#AAF277#002"
        })],
        category: PropertyCategory.PARAMETER,
        valueType: PropertyValueType.Int,
        value: {
            dataType: "Int16", 
            value: {
                get: () => {
                    return new opcua.Variant({ dataType: opcua.DataType.Int16, value: 55 });
                }
            }
        }
    });
    collection.addElements([tempmax, temperature]); 
    /*** Añadir File*/
    addressSpace.addAASFile({
        idShort: "KTM1_Documentation",
        kind: Kind.Instance,
        description: [new opcua.LocalizedText({ locale: "en", text: "Documentation for the KTM1 Controller." }),
            new opcua.LocalizedText({ locale: "it", text: "Documentazione per il Controller KTM1" })],
        submodelElementOf: mysubmodel,
        value: "./aas/files/KTM1/documentation",
        mimeType: "application/pdf"
    });
    /** * Añadir Concept Dictionary*/
    const conceptDictionary = addressSpace.addConceptDictionary({
        browseName: "ConceptDict_1",
        idShort: "ConceptDictionary_1",
        conceptDictionaryOf: myaas,
        description: [new opcua.LocalizedText({ locale: "en", text: "Dicitonary for the temperature controller ." }),
        new opcua.LocalizedText({ locale: "it", text: "Diccionario para el controlador de temperatura" })]
    }).addConceptDescriptionRef([
            new Key({
                idType: KeyType.IRDI,
                local: true,
                type: KeyElements.ConceptDescription,
                value: "0112/2///61360_4#AAE685#001"
            })
        ]).addConceptDescriptionRef([
            new Key({
                idType: KeyType.IRDI,
                local: true,
                type: KeyElements.ConceptDescription,
                value: "0112/2///61360_4#AAF277#002"
            })
        ]);
    /** Añadir ConceptDescription con EmbeddedDataSpecification*/
   const embedded_1 = addressSpace.addEmbeddedDataSpecification({
        browseName: "EmbeddedDS_1",
        hasDataSpecification: [new Key({
            idType: KeyType.URI,
            local: false,
            type: KeyElements.GlobalReference,
            value: "www.admin-shell.io/DataSpecificationTemplates/DataSpecificationIEC61360"
        })],
    }).addDataSpecificationIEC61360({ // Tipo definido por el estandard iec61360
       identifier: "0112/2///61360_4\#AAE685",
        preferredName: "temperature",
        definition: "temperature of a component, or its environment, as a variable",
        dataType: "INT_MEASURE_TYPE",
        unit: "C",
        shortName: "T",
        valueFormat: "NR1 S..4",
        unitId: [new Key({
            idType: KeyType.IRDI,
            local: false,
            type: KeyElements.GlobalReference,
            value: '0112/2///62720\#UAA033\#001' // Preferred name: degree Celsius
        })],
    });
}
    /**
     * Iniciar OPC UA Server
     */
    server.start(function () {
        var endpointUrl = server.endpoints[0].endpointDescriptions()[0].endpointUrl;
        console.log(" the primary server endpoint url is ", endpointUrl);
    });
    server.initialize(post_initialize);