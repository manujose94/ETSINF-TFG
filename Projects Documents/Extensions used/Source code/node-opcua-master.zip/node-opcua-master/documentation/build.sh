#/bin/sh
BASEDIR=$(dirname $0)
echo ${BASEDIR}
cd ${BASEDIR}
../node_modules/.bin/litpro
