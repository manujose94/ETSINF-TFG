module.exports = {
    build_address_space_for_conformance_testing: require("./src/address_space_for_conformance_testing").build_address_space_for_conformance_testing,
};
