/**
 * @module node-opcua-client-dynamic-extension-object
 */
export * from "./client_dynamic_extension_object";
export * from "./extra_data_type_manager";
export * from "./resolve_dynamic_extension_object";
export * from "./promote_opaque_structure";
