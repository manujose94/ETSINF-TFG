module.exports = require("node-opcua-crypto").crypto_explore_certificate;
