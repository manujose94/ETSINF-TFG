/**
 * @module node-opcua-address-space.AlarmsAndConditions
 */
import { UAExclusiveLimitAlarm } from "./ua_exclusive_limit_alarm";

export class UAExclusiveRateOfChangeAlarm extends UAExclusiveLimitAlarm {

}
