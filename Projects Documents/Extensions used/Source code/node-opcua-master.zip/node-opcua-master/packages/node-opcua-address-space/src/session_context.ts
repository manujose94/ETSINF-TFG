/**
 * @module node-opcua-address-space
 */
export { SessionContext } from "../source/session_context";
