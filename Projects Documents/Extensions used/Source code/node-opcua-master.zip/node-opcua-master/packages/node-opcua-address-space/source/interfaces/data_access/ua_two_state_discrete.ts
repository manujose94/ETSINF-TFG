/**
 * @module node-opcua-address-space
 */
import { UAVariable } from "../../address_space_ts";

// tslint:disable:no-empty-interface
export interface UATwoStateDiscrete extends UAVariable {

}
