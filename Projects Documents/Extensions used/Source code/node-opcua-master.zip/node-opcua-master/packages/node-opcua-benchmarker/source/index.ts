/***
 * @module node-opcua-benchmarker
 */
export * from "./benchmarker";
