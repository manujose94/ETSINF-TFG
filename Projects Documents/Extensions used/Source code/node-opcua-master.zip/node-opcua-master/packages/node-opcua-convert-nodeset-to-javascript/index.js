"use strict";
module.exports = {
    createExtensionObjectDefinition: require("./src/convert_nodeset_to_types").createExtensionObjectDefinition,
    nodeset: require("./src/convert_nodeset_to_types").nodeset,

};
