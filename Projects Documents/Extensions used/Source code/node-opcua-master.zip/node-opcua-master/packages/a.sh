echo node-opcua
npm dist-tag add node-opcua@0.5.6 latest
echo node-opcua-address-space
npm dist-tag add node-opcua-address-space@0.5.6 latest
echo node-opcua-address-space-for-conformance-testing
npm dist-tag add node-opcua-address-space-for-conformance-testing@0.5.6 latest
echo node-opcua-assert
npm dist-tag add node-opcua-assert@0.5.6 latest
echo node-opcua-basic-types
npm dist-tag add node-opcua-basic-types@0.5.6 latest
echo node-opcua-benchmarker
npm dist-tag add node-opcua-benchmarker@0.5.6 latest
echo node-opcua-binary-stream
npm dist-tag add node-opcua-binary-stream@0.5.6 latest
echo node-opcua-buffer-utils
npm dist-tag add node-opcua-buffer-utils@0.5.6 latest
echo node-opcua-certificate-manager
npm dist-tag add node-opcua-certificate-manager@0.5.6 latest
echo node-opcua-chunkmanager
npm dist-tag add node-opcua-chunkmanager@0.5.6 latest
echo node-opcua-client
npm dist-tag add node-opcua-client@0.5.6 latest
echo node-opcua-client-crawler
npm dist-tag add node-opcua-client-crawler@0.5.6 latest
echo node-opcua-client-proxy
npm dist-tag add node-opcua-client-proxy@0.5.6 latest
echo node-opcua-common
npm dist-tag add node-opcua-common@0.5.6 latest
echo node-opcua-constants
npm dist-tag add node-opcua-constants@0.5.6 latest
echo node-opcua-convert-nodeset-to-javascript
npm dist-tag add node-opcua-convert-nodeset-to-javascript@0.5.6 latest
echo node-opcua-data-access
npm dist-tag add node-opcua-data-access@0.5.6 latest
echo node-opcua-data-model
npm dist-tag add node-opcua-data-model@0.5.6 latest
echo node-opcua-data-value
npm dist-tag add node-opcua-data-value@0.5.6 latest
echo node-opcua-date-time
npm dist-tag add node-opcua-date-time@0.5.6 latest
echo node-opcua-debug
npm dist-tag add node-opcua-debug@0.5.6 latest
echo node-opcua-end2end-test
npm dist-tag add node-opcua-end2end-test@0.5.6 latest
echo node-opcua-enum
npm dist-tag add node-opcua-enum@0.5.6 latest
echo node-opcua-extension-object
npm dist-tag add node-opcua-extension-object@0.5.6 latest
echo node-opcua-factory
npm dist-tag add node-opcua-factory@0.5.6 latest
echo node-opcua-generator
npm dist-tag add node-opcua-generator@0.5.6 latest
echo node-opcua-guid
npm dist-tag add node-opcua-guid@0.5.6 latest
echo node-opcua-hostname
npm dist-tag add node-opcua-hostname@0.5.6 latest
echo node-opcua-leak-detector
npm dist-tag add node-opcua-leak-detector@0.5.6 latest
echo node-opcua-local-discovery-server
npm dist-tag add node-opcua-local-discovery-server@0.5.6 latest
echo node-opcua-model
npm dist-tag add node-opcua-model@0.5.6 latest
echo node-opcua-nodeid
npm dist-tag add node-opcua-nodeid@0.5.6 latest
echo node-opcua-nodesets
npm dist-tag add node-opcua-nodesets@0.5.6 latest
echo node-opcua-numeric-range
npm dist-tag add node-opcua-numeric-range@0.5.6 latest
echo node-opcua-object-registry
npm dist-tag add node-opcua-object-registry@0.5.6 latest
echo node-opcua-packet-analyzer
npm dist-tag add node-opcua-packet-analyzer@0.5.6 latest
echo node-opcua-packet-assembler
npm dist-tag add node-opcua-packet-assembler@0.5.6 latest
echo node-opcua-pseudo-session
npm dist-tag add node-opcua-pseudo-session@0.5.6 latest
echo node-opcua-samples
npm dist-tag add node-opcua-samples@0.5.6 latest
echo node-opcua-schemas
npm dist-tag add node-opcua-schemas@0.5.6 latest
echo node-opcua-secure-channel
npm dist-tag add node-opcua-secure-channel@0.5.6 latest
echo node-opcua-server
npm dist-tag add node-opcua-server@0.5.6 latest
echo node-opcua-server-discovery
npm dist-tag add node-opcua-server-discovery@0.5.6 latest
echo node-opcua-service-browse
npm dist-tag add node-opcua-service-browse@0.5.6 latest
echo node-opcua-service-call
npm dist-tag add node-opcua-service-call@0.5.6 latest
echo node-opcua-service-discovery
npm dist-tag add node-opcua-service-discovery@0.5.6 latest
echo node-opcua-service-endpoints
npm dist-tag add node-opcua-service-endpoints@0.5.6 latest
echo node-opcua-service-filter
npm dist-tag add node-opcua-service-filter@0.5.6 latest
echo node-opcua-service-history
npm dist-tag add node-opcua-service-history@0.5.6 latest
echo node-opcua-service-node-management
npm dist-tag add node-opcua-service-node-management@0.5.6 latest
echo node-opcua-service-query
npm dist-tag add node-opcua-service-query@0.5.6 latest
echo node-opcua-service-read
npm dist-tag add node-opcua-service-read@0.5.6 latest
echo node-opcua-service-register-node
npm dist-tag add node-opcua-service-register-node@0.5.6 latest
echo node-opcua-service-secure-channel
npm dist-tag add node-opcua-service-secure-channel@0.5.6 latest
echo node-opcua-service-session
npm dist-tag add node-opcua-service-session@0.5.6 latest
echo node-opcua-service-subscription
npm dist-tag add node-opcua-service-subscription@0.5.6 latest
echo node-opcua-service-translate-browse-path
npm dist-tag add node-opcua-service-translate-browse-path@0.5.6 latest
echo node-opcua-service-write
npm dist-tag add node-opcua-service-write@0.5.6 latest
echo node-opcua-status-code
npm dist-tag add node-opcua-status-code@0.5.6 latest
echo node-opcua-test-fixtures
npm dist-tag add node-opcua-test-fixtures@0.5.6 latest
echo node-opcua-test-helpers
npm dist-tag add node-opcua-test-helpers@0.5.6 latest
echo node-opcua-transport
npm dist-tag add node-opcua-transport@0.5.6 latest
echo node-opcua-types
npm dist-tag add node-opcua-types@0.5.6 latest
echo node-opcua-utils
npm dist-tag add node-opcua-utils@0.5.6 latest
echo node-opcua-variant
npm dist-tag add node-opcua-variant@0.5.6 latest
echo node-opcua-vendor-diagnostic
npm dist-tag add node-opcua-vendor-diagnostic@0.5.6 latest
echo node-opcua-xml2json
npm dist-tag add node-opcua-xml2json@0.5.6 latest
