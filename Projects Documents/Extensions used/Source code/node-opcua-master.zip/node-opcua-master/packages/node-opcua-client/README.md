node-opcua-client
=================

an implementation of a OPC UA stack fully written in javascript and nodejs


see http://node-opcua.github.io/

