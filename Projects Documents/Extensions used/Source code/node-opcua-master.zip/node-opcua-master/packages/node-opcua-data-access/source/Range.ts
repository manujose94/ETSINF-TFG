/**
 * @module node-opcua-data-access
 */
export { Range } from "node-opcua-types";
