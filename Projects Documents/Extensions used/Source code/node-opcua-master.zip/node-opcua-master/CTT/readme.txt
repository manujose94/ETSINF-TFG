

* add 127.0.0.1 MYSERVER in your host file (/etc/host or c:\windows\system32\drivers\etc\host)
* run node bin\simple_server.js -a MYSERVER


